package com.minnehahalofts.app

import org.joda.time.LocalDate

class TimeService {

    def currentDate() {
        return LocalDate.now()
    }
}
